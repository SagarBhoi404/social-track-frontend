import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { ArrowRight, Moon, Sun } from "lucide-react";
import { FullScreenLoader } from "./FullScreenLoader";

export const HeroSection = () => {
  const [profileUrl, setProfileUrl] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const { toast } = useToast();


  const handleAnalyze = () => {
    if (!profileUrl) {
      toast({
        title: "Please enter a profile URL",
        variant: "destructive",
      });
      return;
    }
    setIsAnalyzing(true);
    toast({
      title: "Analysis started",
      description: "We're analyzing your social media profile",
    });
    
    setTimeout(() => {
      setIsAnalyzing(false);
    }, 3000);
  };

  return (
    <>
      <FullScreenLoader isOpen={isAnalyzing} />
      <div className="flex flex-col items-center justify-center min-h-[50vh] bg-gradient-to-b from-accent to-accent-secondary dark:from-gray-900 dark:to-gray-800 p-6 animate-fade-up relative">
      
        <h1 className="text-4xl md:text-5xl font-bold text-center mb-4 bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary dark:from-primary-foreground dark:to-secondary-foreground">
          Welcome to SocialLens
        </h1>
        <p className="text-lg md:text-xl text-gray-600 dark:text-gray-300 mb-8 text-center max-w-2xl">
          Unlock the power of your social media insights with advanced analytics and AI-driven recommendations
        </p>
        <div className="flex flex-col md:flex-row gap-4 w-full max-w-xl">
          <Input
            type="url"
            placeholder="Enter your social media profile URL"
            value={profileUrl}
            onChange={(e) => setProfileUrl(e.target.value)}
            className="flex-1 shadow-sm dark:bg-gray-800 dark:border-gray-700 dark:text-gray-100 dark:placeholder-gray-400"
          />
          <Button 
            onClick={handleAnalyze} 
            className="bg-primary hover:opacity-90 transition-all duration-300 transform hover:scale-105 dark:bg-primary dark:text-primary-foreground"
            disabled={isAnalyzing}
          >
            {isAnalyzing ? "Analyzing..." : "Analyze Now"}
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </>
  );
};