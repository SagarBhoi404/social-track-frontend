import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Download, Lightbulb, Copy, ChevronDown, ChevronUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Insight {
  title: string;
  description: string;
  priority: "high" | "medium" | "low";
}

export const AIInsights = () => {
  const { toast } = useToast();
  const [isExpanded, setIsExpanded] = useState(false);

  const insights: Insight[] = [
    {
      title: "Peak Posting Time",
      description: "Post more frequently during peak hours (2 PM - 5 PM) to maximize engagement",
      priority: "high",
    },
    {
      title: "Content Format",
      description: "Increase carousel posts for better engagement, they perform 20% better than single images",
      priority: "medium",
    },
    {
      title: "Video Strategy",
      description: "Use more video content to boost reach, current video engagement is 30% higher",
      priority: "high",
    },
  ];

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard",
      description: "The insight has been copied to your clipboard",
    });
  };

  const handleDownload = () => {
    const text = insights.map(i => `${i.title}\n${i.description}\n`).join('\n');
    const blob = new Blob([text], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'social-insights.txt';
    a.click();
    window.URL.revokeObjectURL(url);
    
    toast({
      title: "Report downloaded",
      description: "Your insights report has been downloaded",
    });
  };

  return (
    <Card className="animate-fade-up bg-accent">
      <CardHeader className="flex flex-row items-center justify-between">
        <div className="flex items-center gap-2">
          <Lightbulb className="h-5 w-5 text-primary" />
          <CardTitle>AI Insights</CardTitle>
        </div>
        <Button variant="outline" size="icon" onClick={handleDownload}>
          <Download className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent>
        <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
          <div className="space-y-4">
            {insights.slice(0, isExpanded ? undefined : 2).map((insight, index) => (
              <div
                key={index}
                className="flex items-start gap-4 p-4 rounded-lg bg-white shadow-sm"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-semibold">{insight.title}</h3>
                    <span
                      className={`px-2 py-1 rounded-full text-xs ${
                        insight.priority === "high"
                          ? "bg-red-100 text-red-700"
                          : insight.priority === "medium"
                          ? "bg-yellow-100 text-yellow-700"
                          : "bg-green-100 text-green-700"
                      }`}
                    >
                      {insight.priority} priority
                    </span>
                  </div>
                  <p className="text-sm text-gray-600">{insight.description}</p>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleCopy(insight.description)}
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
          <CollapsibleTrigger asChild>
            <Button
              variant="ghost"
              className="w-full mt-4"
            >
              {isExpanded ? (
                <ChevronUp className="h-4 w-4 mr-2" />
              ) : (
                <ChevronDown className="h-4 w-4 mr-2" />
              )}
              {isExpanded ? "Show Less" : "Show More"}
            </Button>
          </CollapsibleTrigger>
          <CollapsibleContent className="space-y-4">
            {/* Additional content when expanded */}
          </CollapsibleContent>
        </Collapsible>
      </CardContent>
    </Card>
  );
};