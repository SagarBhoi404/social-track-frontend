import { useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

type Metric = "engagement" | "impressions" | "reach";

const data = [
  { name: "Mon", engagement: 400, impressions: 1000, reach: 800, prevEngagement: 300, prevImpressions: 800, prevReach: 600 },
  { name: "Tue", engagement: 300, impressions: 1200, reach: 900, prevEngagement: 400, prevImpressions: 1000, prevReach: 700 },
  { name: "Wed", engagement: 600, impressions: 1500, reach: 1200, prevEngagement: 500, prevImpressions: 1300, prevReach: 1000 },
  { name: "Thu", engagement: 800, impressions: 1800, reach: 1500, prevEngagement: 700, prevImpressions: 1600, prevReach: 1300 },
  { name: "Fri", engagement: 700, impressions: 1600, reach: 1300, prevEngagement: 600, prevImpressions: 1400, prevReach: 1100 },
];

export const PerformanceGraph = () => {
  const [selectedMetric, setSelectedMetric] = useState<Metric>("engagement");

  const metrics = {
    engagement: { color: "#9b87f5", label: "Engagement" },
    impressions: { color: "#0EA5E9", label: "Impressions" },
    reach: { color: "#10B981", label: "Reach" },
  };

  return (
    <Card className="w-full animate-fade-up">
      <CardHeader>
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <CardTitle>Performance Overview</CardTitle>
          <div className="flex gap-2">
            {(Object.keys(metrics) as Metric[]).map((metric) => (
              <Button
                key={metric}
                variant={selectedMetric === metric ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedMetric(metric)}
                className="capitalize"
              >
                {metrics[metric].label}
              </Button>
            ))}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-white p-4 rounded-lg shadow-lg border">
                        <p className="font-bold">{label}</p>
                        <p className="text-sm text-gray-600">
                          Current: {payload[0].value}
                        </p>
                        <p className="text-sm text-gray-600">
                          Previous: {payload[1].value}
                        </p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Legend />
              <Line
                type="monotone"
                dataKey={selectedMetric}
                stroke={metrics[selectedMetric].color}
                strokeWidth={2}
                name="Current Week"
              />
              <Line
                type="monotone"
                dataKey={`prev${selectedMetric.charAt(0).toUpperCase() + selectedMetric.slice(1)}`}
                stroke={metrics[selectedMetric].color}
                strokeWidth={2}
                strokeDasharray="5 5"
                name="Previous Week"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};