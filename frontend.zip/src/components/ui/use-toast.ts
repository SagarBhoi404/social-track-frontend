// This file should be empty or removed since we're using the hook from /hooks
export { useToast, toast } from "@/hooks/use-toast";