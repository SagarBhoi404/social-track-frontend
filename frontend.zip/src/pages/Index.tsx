import { Image, Video, BarChart2, Users } from "lucide-react";
import { HeroSection } from "@/components/HeroSection";
import { AnalyticsCard } from "@/components/AnalyticsCard";
import { PerformanceGraph } from "@/components/PerformanceGraph";
import { AIInsights } from "@/components/AIInsights";
import { Contributors } from "@/components/Contributors";

const Index = () => {
  return (
    <div className="min-h-screen bg-background dark:bg-gray-900 transition-colors duration-200">
      <HeroSection />
      
      <main className="container py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <AnalyticsCard
            title="Carousel Engagement"
            value="85%"
            description="+20% from last month"
            icon={Image}
          />
          <AnalyticsCard
            title="Reel Performance"
            value="1.2M"
            description="Views this month"
            icon={Video}
          />
          <AnalyticsCard
            title="Weekly Posts"
            value="12"
            description="Average per week"
            icon={BarChart2}
          />
          <AnalyticsCard
            title="Total Reach"
            value="2.5M"
            description="Unique viewers"
            icon={Users}
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          <div className="lg:col-span-2">
            <PerformanceGraph />
          </div>
          <div>
            <AIInsights />
          </div>
        </div>

        <div className="mt-12">
          <Contributors />
        </div>
      </main>
    </div>
  );
};

export default Index;